/** Automatically generated file. DO NOT MODIFY */
package com.example.ch09_03;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}